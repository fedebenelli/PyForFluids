# PyForFluids

PyForFluids is a WIP tool to calculate thermodynamical properties of fluids with
multiple kinds of EoS. Right now it supports:

**Nothing**

[^1]: ![Paper link](https://pubs.acs.org/doi/10.1021/je300655b)
